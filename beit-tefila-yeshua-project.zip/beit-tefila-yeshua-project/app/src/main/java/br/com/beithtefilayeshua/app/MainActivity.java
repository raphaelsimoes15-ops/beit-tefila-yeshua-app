package br.com.beithtefilayeshua.app;
import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color; import android.net.Uri; import android.view.*; import android.widget.*; import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
 int navy=Color.rgb(7,20,38), gold=Color.rgb(212,175,55);
 TextView t(String s,int n){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.WHITE);v.setTextSize(n);v.setGravity(17);v.setPadding(16,16,16,16);return v;}
 Button b(String s){Button x=new Button(this);x.setText(s);x.setTextColor(Color.WHITE);x.setTextSize(16);x.setAllCaps(false);return x;}
 void msg(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 public void onCreate(Bundle x){super.onCreate(x); LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(24,24,24,24);r.setBackgroundColor(navy);
 TextView h=t("BEITH TEFILÁ YESHUA",25);h.setTextColor(gold);r.addView(h);r.addView(t("Parashiot • Apostilas • E-books",17));
 r.addView(t("Materiais digitais de estudos messiânicos\n\nR$ 25,99 cada material",16));
 Button p=b("Parashiot"),a=b("Apostilas"),e=b("E-books"),w=b("Falar comigo pelo WhatsApp"),s=b("Compartilhar aplicativo");
 r.addView(p);r.addView(a);r.addView(e);r.addView(w);r.addView(s); TextView f=t("Por Moré Raphael Simões",14);f.setTextColor(gold);r.addView(f);
 p.setOnClickListener(v->msg("Área de Parashiot — capas e materiais serão adicionados aqui."));
 a.setOnClickListener(v->msg("Área de Apostilas — materiais serão adicionados aqui."));
 e.setOnClickListener(v->msg("Área de E-books — materiais serão adicionados aqui."));
 w.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/5500000000000")));}catch(Exception z){msg("Não foi possível abrir o WhatsApp.");}});
 s.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"Conheça o aplicativo Beith Tefilá Yeshua — Parashiot, Apostilas e E-books.");startActivity(Intent.createChooser(i,"Compartilhar aplicativo"));});
 setContentView(r);}
}
