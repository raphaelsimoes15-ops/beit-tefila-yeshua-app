# Beith Tefilá Yeshua
Aplicativo Android inicial para Parashiot, Apostilas e E-books.
Preço configurado: R$ 25,99 por material.
Autor: Moré Raphael Simões.
IMPORTANTE: substituir o número de WhatsApp de exemplo em MainActivity.java antes da distribuição final.
