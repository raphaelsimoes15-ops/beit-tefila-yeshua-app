# Beit Tefilá Yeshua — Android

Projeto Android para transformar o catálogo digital em um APK compartilhável diretamente pelo WhatsApp.

## Incluído
- Catálogo de Parashot, apostilas e e-books
- Preço padrão R$ 25,99
- Capas de Massei e Toldot já incluídas
- Leitura do PDF de Massei incluído no APK
- Compartilhamento do material
- Botão WhatsApp para contato e venda
- Área “Meus e-books” para cadastrar novos materiais e capas no próprio aparelho
- Identidade visual azul-marinho e dourado

## Gerar o APK
Abra esta pasta no Android Studio e use **Build > Build APK(s)**.
O ambiente de geração usado nesta sessão não possui o Android SDK/Build Tools, portanto não foi possível compilar e validar o binário APK aqui sem inventar um arquivo que não existe.

Depois de gerar, o APK estará em `app/build/outputs/apk/`.
