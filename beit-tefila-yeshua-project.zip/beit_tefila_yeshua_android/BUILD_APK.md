# Gerar o APK

Abra esta pasta no Android Studio (versão recente), aguarde a sincronização do Gradle e use:

**Build > Build APK(s)**

O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Para distribuição privada, recomenda-se gerar uma versão assinada em **Build > Generate Signed Bundle / APK > APK**.

O app não depende de Google Play. O catálogo inicial é local e a Área do Autor salva os novos materiais no próprio aparelho. Para que parceiros recebam novos materiais automaticamente sem instalar outro APK, será necessário ligar o catálogo a um backend/Firebase em uma próxima etapa.

## Compilação automática pelo GitHub Actions

O projeto inclui `.github/workflows/build-apk.yml`. Ao colocar o projeto em um repositório GitHub com a branch `main`, o GitHub Actions compila automaticamente o APK e publica o `app-debug.apk` como artefato para download.
