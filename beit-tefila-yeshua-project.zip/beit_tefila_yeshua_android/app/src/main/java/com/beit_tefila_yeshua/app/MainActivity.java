package com.beit_tefila_yeshua.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import android.net.Uri;
import android.util.Base64;
import androidx.core.content.FileProvider;
import java.io.*;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                if(fileCallback!=null) fileCallback.onReceiveValue(null); fileCallback=cb;
                Intent i=p.createIntent(); try{startActivityForResult(i,1001);}catch(Exception e){fileCallback=null; cb.onReceiveValue(null);} return true;
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(this),"Android");
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==1001 && fileCallback!=null){ Uri[] u=WebChromeClient.FileChooserParams.parseResult(c,d); fileCallback.onReceiveValue(u); fileCallback=null; } }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }

    public static class Bridge {
        Activity a; Bridge(Activity x){a=x;}
        @JavascriptInterface public String saveFile(String dataUrl,String filename,String mime){
            try{
                String b64=dataUrl.substring(dataUrl.indexOf(',')+1);
                byte[] data=Base64.decode(b64,Base64.DEFAULT);
                File dir=new File(a.getFilesDir(),"shared"); if(!dir.exists()) dir.mkdirs();
                File f=new File(dir, filename.replaceAll("[^A-Za-z0-9._-]","_"));
                try(FileOutputStream out=new FileOutputStream(f)){out.write(data);}
                Uri uri=FileProvider.getUriForFile(a,a.getPackageName()+".provider",f);
                return uri.toString();
            }catch(Exception e){return "";}
        }
        @JavascriptInterface public void whatsapp(String text){
            try{ Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/5521998042126?text="+Uri.encode(text))); a.startActivity(i); }catch(Exception e){}
        }
        @JavascriptInterface public void share(String title,String text){
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,title); i.putExtra(Intent.EXTRA_TEXT,text); a.startActivity(Intent.createChooser(i,"Compartilhar material"));
        }
        @JavascriptInterface public void openFile(String uriString){
            try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(uriString));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);a.startActivity(i);}catch(Exception e){}
        }
    }
}
